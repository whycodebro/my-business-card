import React from "react"

export default function Info() {
    return (
        <div className ="info" >
            <img src = "./photo1.jpeg" className = "info--img" />
            <h1> Ayush Jain </h1>
            <h3> Frontend Developer </h3>
            <h4> ayushasj.in </h4>
            <div id = "buttons" >
                <button id= "email--button" > Email </button>
                <button id= "linkedin--button" > Linkedin </button>
            </div>
        </div>
    )
}