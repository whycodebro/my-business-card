import React from "react"

export default function Interests() {
    return (
        <div className = "interests" >
            <h1 className = "interests--title" > Interests </h1>
            <p className = "interests--text" > Food lover. Gardener. Reader. Internet fanatic. Dancer . Entrepreneur. Travel geek. Old school boy. </p>
        </div>
    )
}