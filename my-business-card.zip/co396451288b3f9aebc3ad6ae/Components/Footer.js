import React from "react"

export default function Footer() {
    return (
        <div className = "footer" >
            <img src = "./images/twit.jpg" id = "twit" />
            <img src = "./images/fb.png"/>
            <img src = "./images/insta.png" />
            <img src = "./images/github.png" id="git" />
        </div>
    )
}